import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { CreateAccountComponent } from './components/forms/create-account/create-account.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AccountService } from './services/account.service';
import { httpInterceptors } from '../shared/interceptors';
import { AccountDepositComponent } from './components/forms/account-deposit/account-deposit.component';
import { AccountWithdrawComponent } from './components/forms/account-withdraw/account-withdraw.component';

@NgModule({
  declarations: [CreateAccountComponent, AccountDepositComponent, AccountWithdrawComponent],
  imports: [CommonModule, FormsModule, HttpClientModule, AccountRoutingModule],
  providers: [AccountService, httpInterceptors],
})
export class AccountModule {}
