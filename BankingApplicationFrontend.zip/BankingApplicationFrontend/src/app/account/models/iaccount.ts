export interface IAccount {
  accountType: string;
  panNumber: string;
  aadharNumber: string;
  mobileNumber: string;
  balance: number;
  userId: number;
}
