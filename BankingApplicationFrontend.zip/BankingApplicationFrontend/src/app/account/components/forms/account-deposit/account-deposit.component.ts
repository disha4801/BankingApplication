import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-account-deposit',
  templateUrl: './account-deposit.component.html',
  styleUrls: ['./account-deposit.component.css'],
})
export class AccountDepositComponent implements OnInit {
  amount: number = 0;
  errorMessage: string = '';

  constructor(private accountService: AccountService, private router: Router) {}

  ngOnInit(): void {}

  depositAmount() {
    let accountId = JSON.parse(
      localStorage.getItem('accountDetails') || ''
    ).accountId;

    this.accountService.depositAmount(accountId, this.amount).subscribe(
      (res) => {
        console.log(res);
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.amount = 0;
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        this.errorMessage = err.errors.message;
        console.log(err);
      }
    );
  }
}
