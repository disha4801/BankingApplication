import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/layout/header/header.component';
import { LandingComponent } from './components/layout/landing/landing.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { NotFoundComponent } from './components/common/not-found/not-found.component';
import { UnauthorizedComponent } from './components/common/unauthorized/unauthorized.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
    HeaderComponent,
    LandingComponent,
    FooterComponent,
    NotFoundComponent,
    UnauthorizedComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[
    HeaderComponent,
    FooterComponent,
    LandingComponent,
    CommonModule,
    UnauthorizedComponent,
    NotFoundComponent,
  ]
})
export class CoreModule { }
