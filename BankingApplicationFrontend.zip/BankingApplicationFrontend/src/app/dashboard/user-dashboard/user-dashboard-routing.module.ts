import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserDashboardModule } from './user-dashboard.module';
import { UserComponent } from './components/user/user.component';
import { UserGuard } from 'src/app/shared/guards/user.guard';

const routes: Routes = [
  { path: '', component: UserComponent, canActivate: [UserGuard] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserDashboardRoutingModule {}
